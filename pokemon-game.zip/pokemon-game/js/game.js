// Dados dos monstros (simulando os objetos Java)
const playerMonstro = {
    nome: "Blazer",
    tipo: "Fogo",
    nivel: 5,
    hpMaximo: 100,
    hpAtual: 100,
    ataques: [
        { nome: "Scratch", forca: 20 },
        { nome: "Leer", forca: 0 },
        { nome: "Growl", forca: 0 },
        { nome: null, forca: 0 }
    ]
};

document.addEventListener('DOMContentLoaded', function() {
    console.log('Jogo inicializado!');
    
    // Elementos da interface
    const messageBox = document.getElementById('message-box');
    const mainMenu = document.getElementById('main-menu');
    const attackPanel = document.getElementById('attack-panel');
    const battleButton = document.getElementById('battle-button');
    const monstersButton = document.getElementById('monsters-button');
    const backButton = document.getElementById('back-button');
    const attackButtons = document.querySelectorAll('.attack-button');
    
    // Elementos de HP
    const playerHpFill = document.getElementById('player-hp-fill');
    const playerHpText = document.getElementById('player-hp-text');
    const opponentHpFill = document.getElementById('opponent-hp-fill');
    const opponentHpText = document.getElementById('opponent-hp-text');
    
    // Sprites
    const playerSprite = document.querySelector('.player-sprite');
    const opponentSprite = document.querySelector('.opponent-sprite');
    
    const opponentMonstro = {
        nome: "Wildmon",
        tipo: "Normal",
        nivel: 5,
        hpMaximo: 100,
        hpAtual: 100,
        ataques: [
            { nome: "Tackle", forca: 18 }
        ]
    };
    
    // Estado do jogo
    let battleActive = false;
    let playerTurn = true;
    
    // Inicialização da interface
    function initializeInterface() {
        // Atualiza os nomes dos ataques nos botões
        attackButtons.forEach((button, index) => {
            const ataque = playerMonstro.ataques[index];
            if (ataque && ataque.nome) {
                button.textContent = ataque.nome;
                button.disabled = false;
            } else {
                button.textContent = "-";
                button.disabled = true;
            }
        });
        
        // Atualiza as barras de HP
        updateHpDisplay();
    }
    
    // Função para atualizar as barras de HP
    function updateHpDisplay() {
        // Calcula as porcentagens de HP
        const playerHpPercent = (playerMonstro.hpAtual / playerMonstro.hpMaximo) * 100;
        const opponentHpPercent = (opponentMonstro.hpAtual / opponentMonstro.hpMaximo) * 100;
        
        // Atualiza as barras visuais
        playerHpFill.style.width = `${playerHpPercent}%`;
        opponentHpFill.style.width = `${opponentHpPercent}%`;
        
        // Muda a cor da barra baseado no HP restante
        if (playerHpPercent > 50) {
            playerHpFill.style.backgroundColor = "#4CAF50"; // Verde
        } else if (playerHpPercent > 20) {
            playerHpFill.style.backgroundColor = "#FFC107"; // Amarelo
        } else {
            playerHpFill.style.backgroundColor = "#F44336"; // Vermelho
        }
        
        if (opponentHpPercent > 50) {
            opponentHpFill.style.backgroundColor = "#4CAF50";
        } else if (opponentHpPercent > 20) {
            opponentHpFill.style.backgroundColor = "#FFC107";
        } else {
            opponentHpFill.style.backgroundColor = "#F44336";
        }
        
        // Atualiza os textos de HP
        playerHpText.textContent = `${playerMonstro.hpAtual}/${playerMonstro.hpMaximo}`;
        opponentHpText.textContent = `${opponentMonstro.hpAtual}/${opponentMonstro.hpMaximo}`;
    }
    
    // Função para aplicar dano
    function aplicarDano(alvo, dano) {
        alvo.hpAtual = Math.max(0, alvo.hpAtual - dano);
        updateHpDisplay();
    }
    
    // Função para animar o dano
    function animarDano(elemento) {
        elemento.classList.add('damage-animation');
        setTimeout(() => {
            elemento.classList.remove('damage-animation');
        }, 500);
    }
    
    // Função para mostrar mensagem
    function showMessage(message) {
        messageBox.textContent = message;
    }
    
    // Função para iniciar batalha
    function startBattle() {
        battleActive = true;
        playerTurn = true;
        mainMenu.style.display = 'none';
        attackPanel.style.display = 'block';
        showMessage(`Uma batalha começou! ${playerMonstro.nome} vs ${opponentMonstro.nome}!`);
    }
    
    // Função para encerrar batalha
    function endBattle(playerWon) {
        battleActive = false;
        attackPanel.style.display = 'none';
        mainMenu.style.display = 'flex';
        
        if (playerWon) {
            showMessage(`Você venceu! ${opponentMonstro.nome} foi derrotado!`);
        } else {
            showMessage(`Você perdeu! ${playerMonstro.nome} foi derrotado!`);
        }
        
        // Restaura HP para próxima batalha
        playerMonstro.hpAtual = playerMonstro.hpMaximo;
        opponentMonstro.hpAtual = opponentMonstro.hpMaximo;
        updateHpDisplay();
    }
    
    // Função para processar o turno do oponente
    function opponentTurn() {
        setTimeout(() => {
            const ataque = opponentMonstro.ataques[0]; // Sempre usa o primeiro ataque
            showMessage(`${opponentMonstro.nome} usou ${ataque.nome}!`);
            
            setTimeout(() => {
                animarDano(playerSprite);
                aplicarDano(playerMonstro, ataque.forca);
                
                setTimeout(() => {
                    if (playerMonstro.hpAtual <= 0) {
                        endBattle(false);
                    } else {
                        playerTurn = true;
                        showMessage("Escolha seu ataque!");
                    }
                }, 1000);
            }, 1000);
        }, 1000);
    }
    
    // Classe para o botão de reset
    class ResetButton {
        constructor(containerId) {
            this.button = document.createElement('button');
            this.button.textContent = 'Resetar';
            this.button.className = 'menu-button';
            this.button.id = 'reset-button';
            document.getElementById(containerId).appendChild(this.button);
            this.button.addEventListener('click', () => this.resetarJogo());
        }

        resetarJogo() {
            // Restaura os HPs
            playerMonstro.hpAtual = playerMonstro.hpMaximo;
            opponentMonstro.hpAtual = opponentMonstro.hpMaximo;
            updateHpDisplay();
            // Restaura menus
            attackPanel.style.display = 'none';
            mainMenu.style.display = 'left';
            showMessage('O que você deseja fazer?');
        }
    }

    // Adiciona o botão de reset ao menu principal
    new ResetButton('main-menu');

    // Event Listeners
    battleButton.addEventListener('click', function() {
        startBattle();
    });
    
    monstersButton.addEventListener('click', function() {
        mostrarMeusMonstros();
    });
    
    backButton.addEventListener('click', function() {
        if (!battleActive) {
            attackPanel.style.display = 'none';
            mainMenu.style.display = 'flex';
        } else {
            showMessage("Oque você deseja fazer?");
        }
    });
    
    // Event listeners para os botões de ataque
    attackButtons.forEach((button, index) => {
        button.addEventListener('click', function() {
            if (!battleActive || !playerTurn) return;
            
            playerTurn = false;
            const ataque = playerMonstro.ataques[index];
            
            if (!ataque || !ataque.nome) return;
            
            showMessage(`${playerMonstro.nome} usou ${ataque.nome}!`);
            
            setTimeout(() => {
                animarDano(opponentSprite);
                aplicarDano(opponentMonstro, ataque.forca);
                
                setTimeout(() => {
                    if (opponentMonstro.hpAtual <= 0) {
                        endBattle(true);
                    } else {
                        showMessage(`${opponentMonstro.nome} está se preparando para atacar...`);
                        opponentTurn();
                    }
                }, 1000);
            }, 1000);
        });
    });
    
    // Adiciona listeners aos botões do painel de monstros
    document.getElementById('prev-monster-button').onclick = anteriorMonstro;
    document.getElementById('next-monster-button').onclick = proximoMonstro;
    document.getElementById('close-monsters-button').onclick = fecharMeusMonstros;

    // Inicializa a interface
    initializeInterface();
});

// Exemplo de função para abrir o painel de ataques
function abrirPainelAtaque() {
    document.getElementById('main-menu').style.display = 'none';
    document.getElementById('attack-panel').style.display = 'block';
}
document.getElementById('back-button').onclick = function() {
    document.getElementById('attack-panel').style.display = 'none';
    document.getElementById('main-menu').style.display = 'flex';
};

// Exemplo de lista de monstros do jogador
const meusMonstros = [
    {
        nome: "Blazer",
        tipo: "Fogo",
        hpMaximo: 100,
        hp: 100,
        sprite: "https://github.com/PokeAPI/sprites/blob/master/sprites/pokemon/versions/generation-v/black-white/animated/back/25.gif?raw=true",
        ataques: [
            { nome: "Scratch", forca: 20 },
            { nome: "Ember", forca: 22 },
            { nome: "Growl", forca: 0 },
            { nome: null, forca: 0 }
        ]
    },
    {
        nome: "Aquata",
        tipo: "Água",
        hpMaximo: 90,
        hp: 90,
        sprite: "https://github.com/PokeAPI/sprites/blob/master/sprites/pokemon/versions/generation-v/black-white/animated/back/7.gif?raw=true",
        ataques: [
            { nome: "Tackle", forca: 18 },
            { nome: "Bubble", forca: 21 },
            { nome: "Tail Whip", forca: 0 },
            { nome: null, forca: 0 }
        ]
    },
    {
        nome: "Leafy",
        tipo: "Planta",
        hpMaximo: 80,
        hp: 80,
        sprite: "https://github.com/PokeAPI/sprites/blob/master/sprites/pokemon/versions/generation-v/black-white/animated/back/1.gif?raw=true",
        ataques: [
            { nome: "Vine Whip", forca: 19 },
            { nome: "Tackle", forca: 18 },
            { nome: "Growl", forca: 0 },
            { nome: null, forca: 0 }
        ]
    }
];

let indiceMonstroAtual = 0;
let indiceMonstroSelecionado = 0;

// Atualiza o monstro ativo na batalha ao selecionar
function selecionarMonstroAtual() {
    indiceMonstroSelecionado = indiceMonstroAtual;
    atualizarMonstroBatalha(); // <-- CHAME ESTA FUNÇÃO AQUI!
    mostrarMonstroAtual();
}

// Atualiza nome, sprite, HP e ataques do monstro selecionado na arena
function atualizarMonstroBatalha() {
    const monstro = meusMonstros[indiceMonstroSelecionado];
    playerMonstro.nome = monstro.nome;
    playerMonstro.tipo = monstro.tipo;
    playerMonstro.hpMaximo = monstro.hpMaximo;
    playerMonstro.hpAtual = monstro.hp; // Mantém o HP do monstro
    playerMonstro.ataques = monstro.ataques;

    // Atualiza nome na arena
    document.getElementById('player-name').textContent = monstro.nome;
    // Atualiza sprite
    document.querySelector('.player-sprite').style.backgroundImage = `url('${monstro.sprite}')`;
    // Atualiza ataques nos botões
    document.querySelectorAll('.attack-button').forEach((button, index) => {
        const ataque = monstro.ataques[index];
        if (ataque && ataque.nome) {
            button.textContent = ataque.nome;
            button.disabled = false;
        } else {
            button.textContent = "-";
            button.disabled = true;
        }
    });
    // Atualiza HP na interface
    updateHpDisplay();
}

// Mostra o monstro atual no painel de seleção
function mostrarMonstroAtual() {
    const view = document.getElementById('my-monster-view');
    const monstro = meusMonstros[indiceMonstroAtual];
    const selecionado = indiceMonstroAtual === indiceMonstroSelecionado;
    view.innerHTML = `
        <div class="monster-list-item" style="text-align:center;">
            <img src="${monstro.sprite}" alt="${monstro.nome}" style="width:80px;height:80px;display:block;margin:auto;">
            <strong>${monstro.nome}</strong><br>
            HP: ${monstro.hp} / ${monstro.hpMaximo}<br>
            <button class="menu-button" id="select-monster-button" ${selecionado ? 'disabled' : ''}>
                ${selecionado ? 'Selecionado' : 'Selecionar'}
            </button>
        </div>
        <div style="font-size:12px;color:#888;">
            Monstro ${indiceMonstroAtual + 1} de ${meusMonstros.length}
        </div>
    `;

    // Adiciona o evento ao botão "Selecionar" sempre que o painel é atualizado
    if (!selecionado) {
        document.getElementById('select-monster-button').onclick = selecionarMonstroAtual;
    }
}

// Mostra os monstros do jogador
function mostrarMeusMonstros() {
    document.getElementById('main-menu').style.display = 'none';
    document.getElementById('my-monsters-panel').style.display = 'block';
    mostrarMonstroAtual();
}

// Fecha o painel de monstros
function fecharMeusMonstros() {
    document.getElementById('my-monsters-panel').style.display = 'none';
    document.getElementById('main-menu').style.display = 'block';
}

// Navega para o próximo monstro
function proximoMonstro() {
    if (indiceMonstroAtual < meusMonstros.length - 1) {
        indiceMonstroAtual++;
        mostrarMonstroAtual();
    }
}

// Navega para o monstro anterior
function anteriorMonstro() {
    if (indiceMonstroAtual > 0) {
        indiceMonstroAtual--;
        mostrarMonstroAtual();
    }
}